#ifndef __SENSOR_ADXL362_H__
#define __SENSOR_ADXL362_H__
/******************************************************************************/
/***************************** Include Files **********************************/
/******************************************************************************/
#include "os/mynewt.h"
#include "sensor/sensor.h"

/******************************************************************************/
/********************************* ADXL362 ************************************/
/******************************************************************************/

/* ADXL362 communication commands */
#define ADXL362_WRITE_REG               0x0A
#define ADXL362_READ_REG                0x0B
#define ADXL362_WRITE_FIFO              0x0D

/* Registers */
#define ADXL362_REG_DEVID_AD            0x00
#define ADXL362_REG_DEVID_MST           0x01
#define ADXL362_REG_PARTID              0x02
#define ADXL362_REG_REVID               0x03
#define ADXL362_REG_XDATA               0x08
#define ADXL362_REG_YDATA               0x09
#define ADXL362_REG_ZDATA               0x0A
#define ADXL362_REG_STATUS              0x0B
#define ADXL362_REG_FIFO_L              0x0C
#define ADXL362_REG_FIFO_H              0x0D
#define ADXL362_REG_XDATA_L             0x0E
#define ADXL362_REG_XDATA_H             0x0F
#define ADXL362_REG_YDATA_L             0x10
#define ADXL362_REG_YDATA_H             0x11
#define ADXL362_REG_ZDATA_L             0x12
#define ADXL362_REG_ZDATA_H             0x13
#define ADXL362_REG_TEMP_L              0x14
#define ADXL362_REG_TEMP_H              0x15
#define ADXL362_REG_SOFT_RESET          0x1F
#define ADXL362_REG_THRESH_ACT_L        0x20
#define ADXL362_REG_THRESH_ACT_H        0x21
#define ADXL362_REG_TIME_ACT            0x22
#define ADXL362_REG_THRESH_INACT_L      0x23
#define ADXL362_REG_THRESH_INACT_H      0x24
#define ADXL362_REG_TIME_INACT_L        0x25
#define ADXL362_REG_TIME_INACT_H        0x26
#define ADXL362_REG_ACT_INACT_CTL       0x27
#define ADXL362_REG_FIFO_CTL            0x28
#define ADXL362_REG_FIFO_SAMPLES        0x29
#define ADXL362_REG_INTMAP1             0x2A
#define ADXL362_REG_INTMAP2             0x2B
#define ADXL362_REG_FILTER_CTL          0x2C
#define ADXL362_REG_POWER_CTL           0x2D
#define ADXL362_REG_SELF_TEST           0x2E

/* ADXL362_REG_STATUS definitions */
#define ADXL362_STATUS_ERR_USER_REGS    (1 << 7)
#define ADXL362_STATUS_AWAKE            (1 << 6)
#define ADXL362_STATUS_INACT            (1 << 5)
#define ADXL362_STATUS_ACT              (1 << 4)
#define ADXL362_STATUS_FIFO_OVERRUN     (1 << 3)
#define ADXL362_STATUS_FIFO_WATERMARK   (1 << 2)
#define ADXL362_STATUS_FIFO_RDY         (1 << 1)
#define ADXL362_STATUS_DATA_RDY         (1 << 0)

/* ADXL362_REG_ACT_INACT_CTL definitions */
#define ADXL362_ACT_INACT_CTL_LINKLOOP(x)   (((x) & 0x3) << 4)
#define ADXL362_ACT_INACT_CTL_INACT_REF     (1 << 3)
#define ADXL362_ACT_INACT_CTL_INACT_EN      (1 << 2)
#define ADXL362_ACT_INACT_CTL_ACT_REF       (1 << 1)
#define ADXL362_ACT_INACT_CTL_ACT_EN        (1 << 0)

/* ADXL362_ACT_INACT_CTL_LINKLOOP(x) options */
#define ADXL362_MODE_DEFAULT            0
#define ADXL362_MODE_LINK               1
#define ADXL362_MODE_LOOP               3

/* ADXL362_REG_FIFO_CTL */
#define ADXL362_FIFO_CTL_AH             (1 << 3)
#define ADXL362_FIFO_CTL_FIFO_TEMP      (1 << 2)
#define ADXL362_FIFO_CTL_FIFO_MODE(x)   (((x) & 0x3) << 0)

/* ADXL362_FIFO_CTL_FIFO_MODE(x) options */
#define ADXL362_FIFO_DISABLE            0
#define ADXL362_FIFO_OLDEST_SAVED       1
#define ADXL362_FIFO_STREAM             2
#define ADXL362_FIFO_TRIGGERED          3

/* ADXL362_REG_INTMAP1 */
#define ADXL362_INTMAP1_INT_LOW         (1 << 7)
#define ADXL362_INTMAP1_AWAKE           (1 << 6)
#define ADXL362_INTMAP1_INACT           (1 << 5)
#define ADXL362_INTMAP1_ACT             (1 << 4)
#define ADXL362_INTMAP1_FIFO_OVERRUN    (1 << 3)
#define ADXL362_INTMAP1_FIFO_WATERMARK  (1 << 2)
#define ADXL362_INTMAP1_FIFO_READY      (1 << 1)
#define ADXL362_INTMAP1_DATA_READY      (1 << 0)

/* ADXL362_REG_INTMAP2 definitions */
#define ADXL362_INTMAP2_INT_LOW         (1 << 7)
#define ADXL362_INTMAP2_AWAKE           (1 << 6)
#define ADXL362_INTMAP2_INACT           (1 << 5)
#define ADXL362_INTMAP2_ACT             (1 << 4)
#define ADXL362_INTMAP2_FIFO_OVERRUN    (1 << 3)
#define ADXL362_INTMAP2_FIFO_WATERMARK  (1 << 2)
#define ADXL362_INTMAP2_FIFO_READY      (1 << 1)
#define ADXL362_INTMAP2_DATA_READY      (1 << 0)

/* ADXL362_REG_FILTER_CTL definitions */
#define ADXL362_FILTER_CTL_RANGE(x)     (((x) & 0x3) << 6)
#define ADXL362_FILTER_CTL_RES          (1 << 5)
#define ADXL362_FILTER_CTL_HALF_BW      (1 << 4)
#define ADXL362_FILTER_CTL_EXT_SAMPLE   (1 << 3)
#define ADXL362_FILTER_CTL_ODR(x)       (((x) & 0x7) << 0)

/* ADXL362_FILTER_CTL_RANGE(x) options */
#define ADXL362_RANGE_2G                0 /* +/-2 g */
#define ADXL362_RANGE_4G                1 /* +/-4 g */
#define ADXL362_RANGE_8G                2 /* +/-8 g */

/* ADXL362_FILTER_CTL_ODR(x) options */
#define ADXL362_ODR_12_5_HZ             0 /* 12.5 Hz */
#define ADXL362_ODR_25_HZ               1 /* 25 Hz */
#define ADXL362_ODR_50_HZ               2 /* 50 Hz */
#define ADXL362_ODR_100_HZ              3 /* 100 Hz */
#define ADXL362_ODR_200_HZ              4 /* 200 Hz */
#define ADXL362_ODR_400_HZ              5 /* 400 Hz */

/* ADXL362_REG_POWER_CTL definitions */
#define ADXL362_POWER_CTL_RES           (1 << 7)
#define ADXL362_POWER_CTL_EXT_CLK       (1 << 6)
#define ADXL362_POWER_CTL_LOW_NOISE(x)  (((x) & 0x3) << 4)
#define ADXL362_POWER_CTL_WAKEUP        (1 << 3)
#define ADXL362_POWER_CTL_AUTOSLEEP     (1 << 2)
#define ADXL362_POWER_CTL_MEASURE(x)    (((x) & 0x3) << 0)

/* ADXL362_POWER_CTL_LOW_NOISE(x) options */
#define ADXL362_NOISE_MODE_NORMAL       0
#define ADXL362_NOISE_MODE_LOW          1
#define ADXL362_NOISE_MODE_ULTRALOW     2

/* ADXL362_POWER_CTL_MEASURE(x) options */
#define ADXL362_MEASURE_STANDBY         0
#define ADXL362_MEASURE_ON              2

/* ADXL362_REG_SELF_TEST */
#define ADXL362_SELF_TEST_ST            (1 << 0)

/* ADXL362 device information */
#define ADXL362_DEVICE_AD               0xAD
#define ADXL362_DEVICE_MST              0x1D
#define ADXL362_PART_ID                 0xF2

/* ADXL362 Reset settings */
#define ADXL362_RESET_KEY               0x52




/******************************************************************************/
/********************** Macros and Constants Definitions **********************/
/******************************************************************************/


#define	SPI_CPHA	0x01
#define	SPI_CPOL	0x02
#define EINVAL 9943
#define ENOSYS 88

/******************************************************************************/
/*************************** Types Declarations *******************************/
/******************************************************************************/
/**
 * @enum spi_mode
 * @brief SPI configuration for clock phase and polarity.
 */
enum spi_mode {
	/** Data on rising, shift out on falling */
	SPI_MODE_0 = (0 | 0),
	/** Data on falling, shift out on rising */
	SPI_MODE_1 = (0 | SPI_CPHA),
	/** Data on falling, shift out on rising */
	SPI_MODE_2 = (SPI_CPOL | 0),
	/** Data on rising, shift out on falling */
	SPI_MODE_3 = (SPI_CPOL | SPI_CPHA)
};

/**
 * @enum spi_bit_order
 * @brief SPI configuration for bit order (MSB/LSB).
 */
enum spi_bit_order {
	/** Most-significant bit (MSB) first */
	SPI_BIT_ORDER_MSB_FIRST = 0,
	/** Least-significant bit (LSB) first */
	SPI_BIT_ORDER_LSB_FIRST = 1,
};

/**
 * @struct spi_msg_list
 * @brief List item describing a SPI transfer
 */
struct spi_msg {
	/** Buffer with data to send. If NULL, 0x00 will be sent */
	uint8_t			*tx_buff;
	/** Buffer where to store data. If NULL, incoming data won't be saved */
	uint8_t			*rx_buff;
	/** Length of buffers. Must have equal size. */
	uint32_t		bytes_number;
	/** If set, CS will be deasserted after the transfer */
	uint8_t			cs_change;
	/**
	 * Minimum delay (in us) between the CS de-assert event of the current message
	 * and the assert of the next one.
	 */
	uint32_t		cs_change_delay;
	/** Delay (in us) between the CS assert and the first SCLK edge. */
	uint32_t		cs_delay_first;
	/** Delay (in us) between the last SCLK edge and the CS deassert */
	uint32_t		cs_delay_last;
};
struct spi_platform_ops {
	/** SPI initialization function pointer */
	int32_t (*init)(struct spi_desc **, const struct spi_init_param *);
	/** SPI write/read function pointer */
	int32_t (*write_and_read)(struct spi_desc *, uint8_t *, uint16_t);
	/** Iterate over the spi_msg array and send all messages at once */
	int32_t (*transfer)(struct spi_desc *, struct spi_msg *, uint32_t);
	/** SPI remove function pointer */
	int32_t (*remove)(struct spi_desc *);
}
struct spi_desc {
	/** Device ID */
	uint32_t	device_id;
	/** maximum transfer speed */
	uint32_t	max_speed_hz;
	/** SPI chip select */
	uint8_t		chip_select;
	/** SPI mode */
	enum spi_mode	mode;
	/** SPI bit order */
	enum spi_bit_order	bit_order;
	const struct spi_platform_ops *platform_ops;
	/**  SPI extra parameters (device specific) */
	void		*extra;
	/** Parent of the device */
	struct spi_desc *parent;
};
struct spi_init_param {
	/** Device ID */
	uint32_t	device_id;
	/** maximum transfer speed */
	uint32_t	max_speed_hz;
	/** SPI chip select */
	uint8_t		chip_select;
	/** SPI mode */
	enum spi_mode	mode;
	/** SPI bit order */
	enum spi_bit_order	bit_order;
	const struct spi_platform_ops *platform_ops;
	/**  SPI extra parameters (device specific) */
	void		*extra;
	/** Parent of the device */
	struct spi_desc *parent;
};
/**
 * @struct adxl362_dev
 * @brief ADXL362 Device structure.
 */
struct adxl362_dev {
	/** SPI Descriptor */
	struct spi_desc	*spi_desc;
	/** Measurement Range: */
	uint8_t		selected_range;
};

/**
 * @struct adxl362_init_param
 * @brief Structure holding the parameters for ADXL362 device initialization.
 */
struct adxl362_init_param {
	/** SPI Initialization structure. */
	struct spi_init_param	spi_init;
};
int32_t spi_init(struct spi_desc **desc,
		       const struct spi_init_param *param)
{
	int32_t ret;

	if (!param || !param->platform_ops)
		return -EINVAL;

	if (!param->platform_ops->init)
		return -ENOSYS;

	ret = param->platform_ops->init(desc, param);
	if (ret)
		return ret;

	(*desc)->platform_ops = param->platform_ops;
	(*desc)->parent = param->parent;

	return 0;
}

int32_t spi_remove(struct spi_desc *desc)
{
	if (!desc || !desc->platform_ops)
		return -EINVAL;

	if (!desc->platform_ops->remove)
		return -ENOSYS;

	return desc->platform_ops->remove(desc);
}

/******************************************************************************/
/************************ Functions Declarations ******************************/
/******************************************************************************/




int32_t adxl362_init(struct adxl362_dev **device,
		     struct adxl362_init_param init_param);

/*! Free the resources allocated by adxl362_init(). */
int32_t adxl362_remove(struct adxl362_dev *dev);

/*! Writes data into a register. */
void adxl362_set_register_value(struct adxl362_dev *dev,
				uint16_t register_value,
				uint8_t  register_address,
				uint8_t  bytes_number);

/*! Performs a burst read of a specified number of registers. */
void adxl362_get_register_value(struct adxl362_dev *dev,
				uint8_t *read_data,
				uint8_t  register_address,
				uint8_t  bytes_number);

/*! Reads multiple bytes from the device's FIFO buffer. */
void adxl362_get_fifo_value(struct adxl362_dev *dev,
			    uint8_t *buffer,
			    uint16_t bytes_number);

/*! Resets the device via SPI communication bus. */
void adxl362_software_reset(struct adxl362_dev *dev);

/*! Places the device into standby/measure mode. */
void adxl362_set_power_mode(struct adxl362_dev *dev,
			    uint8_t pwr_mode);

/*! Selects the measurement range. */
void adxl362_set_range(struct adxl362_dev *dev,
		       uint8_t g_range);

/*! Selects the Output Data Rate of the device. */
void adxl362_set_output_rate(struct adxl362_dev *dev,
			     uint8_t out_rate);

/*! Reads the 3-axis raw data from the accelerometer. */
void adxl362_get_xyz(struct adxl362_dev *dev,
		     int16_t *x,
		     int16_t *y,
		     int16_t *z);

/*! Reads the 3-axis raw data from the accelerometer and converts it to g. */
void adxl362_get_g_xyz(struct adxl362_dev *dev,
		       float* x,
		       float* y,
		       float* z);

/*! Reads the temperature of the device. */
float adxl362_read_temperature(struct adxl362_dev *dev);

/*! Configures the FIFO feature. */
void adxl362_fifo_setup(struct adxl362_dev *dev,
			uint8_t  mode,
			uint16_t water_mark_lvl,
			uint8_t  en_temp_read);

/*! Configures activity detection. */
void adxl362_setup_activity_detection(struct adxl362_dev *dev,
				      uint8_t  ref_or_abs,
				      uint16_t threshold,
				      uint8_t  time);

/*! Configures inactivity detection. */
void adxl362_setup_inactivity_detection(struct adxl362_dev *dev,
					uint8_t  ref_or_abs,
					uint16_t threshold,
					uint16_t time);


#endif /* __ADXL362_H__ */